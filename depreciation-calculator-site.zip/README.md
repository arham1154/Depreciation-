# Depreciation Calculator

A simple depreciation and tax-saving calculator for Indian business owners.
Enter what you bought, the rate fills in automatically, and it shows the
year-by-year write-off and the tax you won't pay.

Installable on a phone home screen and works offline.

Not tax advice — check with a CA before filing.
